# Weighted maximum coverage

#' Weighted maximum coverage
#' 
#' This function estimates the weighted maximum coverage
#' 
#' @param x Named vector of weights
#' @param k Integer indicating the number of elements to choose
#' @param sets list of character string vectors
#' @param w Number indicating the penalty power
#' @param reposition Logical, whether the fill-in should be performed with reposition
#' @return Vector of character strings
#' @export
coverage <- function(x, k, sets, w=0, reposition=F) {
  x <- x[names(x) %in% unique(unlist(sets, use.names=F))]
  sets <- lapply(sets, function(x, gene) x[x %in% gene], gene=unique(names(x)))
  gr <- sets
  res <- NULL
  while(length(res)<k) {
    gr <- lapply(gr, function(x, gene) x[x %in% gene], gene=names(x))
    scc <- sapply(gr, function(x, res) 1/(length(which(x %in% res))+1), res=res)^w
    ss <- x[match(unlist(gr, use.names=F), names(x))]*rep(scc[match(names(gr), names(scc))], sapply(gr, length))
    ss <- tapply(ss, names(ss), sum)
    res <- c(res, names(ss)[which.max(ss)])
    x <- x[-which(names(x)==res[length(res)])]
    if (!reposition) {
      gr <- gr[which(!sapply(gr, function(x, gene) any(x==gene), gene=res[length(res)]))]
      if(length(gr)==0) gr <- sets
    }
  }
  return(res)
}
