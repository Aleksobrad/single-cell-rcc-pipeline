#' Generates a table for LATEX
#'
#' This function generates a file containing a LATEX formated table
#'
#' @param x Matrix containing the information for the table, including column names
#' @param fname Character string indicating the name of the output file
#' @param title Integer indicating the number of rows to be used as column titles
#' @return Nothing, a text file containing the LATEX formated table is generated
#' @export

textable <- function(x, fname, title=1) {
	f1 <- file(fname, open="wt")
	cat("\\begin{center}\n", file=f1)
	cat("\\begin{tabular}{", rep("l", ncol(x)), "}\n", sep="", file=f1)
	if (length(title)>0) {
		cat("\\toprule\n", file=f1)
		tmp <- apply(filterRowMatrix(x, title), 1, function(x, f1) cat(paste(x, collapse=" & "), " \\\\\n", sep="", file=f1), f1=f1)
		cat("\\midrule\n", file=f1)
	}
	tmp <- apply(filterRowMatrix(x, (1:nrow(x))[-title]), 1, function(x, f1) cat(paste(x, collapse=" & "), " \\\\\n", sep="", file=f1), f1=f1)
  cat("\\bottomrule\n", file=f1)
  cat("\\end{tabular}\n", file=f1)
  cat("\\end{center}\n", file=f1)
  close(f1)
}

