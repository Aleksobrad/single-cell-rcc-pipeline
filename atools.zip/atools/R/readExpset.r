#' Read expression sets
#'
#' This function reads expression-sets
#'
#' @param filename Character string indicating the name of the input file
#' @return List of two elements, containing the dataset (\code{dset}) and the annotation vector (\code{annotation})
#' @export

readExpset <- function(filename){
  a <- strsplit(readLines(filename), "\t")
  id <- sapply(a[-1], function(x, pos) x[pos], pos=which(tolower(a[[1]]) %in% c("probe", "probeid", "affyid"))[1])
  filtro <- tolower(a[[1]]) %in% c("gene", "entrezid", "affyid", "probe", "probeid", "symbol")
  eset <- t(sapply(a[-1], function(x, filtro) as.numeric(x[filtro]), filtro=!filtro))
  colnames(eset) <- a[[1]][!filtro]
  rownames(eset) <- id
  annot <- sapply(a[-1], function(x, pos) x[pos], pos=which(tolower(a[[1]]) %in% c("gene", "entrezid", "symbol")))
  names(annot) <- rownames(eset)
  return(list(dset=eset, annotation=annot))
}

