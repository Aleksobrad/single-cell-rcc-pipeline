# Functions for RNAseq raw data process

#' Mapping RNAseqw reads
#' 
#' This function maps RNAseq reads to a reference genome and generate bam files
#' 
#' @param filen Vector of character strings indicating the file names
#' @param genome Character string indicating the name of the reference genome
#' @param cs Logical, whether colour space is used
#' @return Nothing, bam and exp files are generated
#' @export
parallelMapping <- function(filen, genome, cs=F) {
  ofile <- paste("m", substr(as.vector(Sys.time()), 6, 10), sep="")
  tname <- NULL
  for (i in 1:length(filen)) {
    tname <- c(tname, paste(ofile, i, sep=""))
    f1 <- file(paste(tname[length(tname)], ".sh", sep=""), open="wt")
    switch(sapply(strsplit(filen[i], "\\."), function(x) x[length(x)]), 
      srf={
        cat("#!/bin/bash\n#\n#$ -cwd\n#$ -j y\n#$ -l mem=8G,time=4::\n#$ -S /bin/bash\n#$ -N ", tname[length(tname)], "\n", sep="", file=f1)
        cat("export BOWTIE_INDEXES=/ifs/scratch/c2b2/ac_lab/malvarez/databases/bowtie\n", file=f1)
        cat("/ifs/scratch/c2b2/ac_lab/malvarez/bin/bin/srf2fasta -C ", filen[i], " > ", sub(".srf", ".fa", filen[i]), "\n", sep="", file=f1)
#        if (cs) cat("bowtie -f -n 3 -e 100 -l 35 -p 8 --sam -C --best ", genome, "_c ", sub(".srf", ".fa", filen[i]), " ", sub(".srf", ".sam", filen[i]), "\n", sep="", file=f1)
        if (cs) cat("bowtie -f -p 8 --sam -C --best ", genome, "_c ", sub(".srf", ".fa", filen[i]), " ", sub(".srf", ".sam", filen[i]), "\n", sep="", file=f1)
        else cat("bowtie -f -p 8 --sam --best ", genome, " ", sub(".srf", ".fa", filen[i]), " ", sub(".srf", ".sam", filen[i]), "\n", sep="", file=f1)
        cat("/ifs/scratch/c2b2/ac_lab/malvarez/bin/samtools/samtools import /ifs/scratch/c2b2/ac_lab/malvarez/databases/samtools/", genome, ".fa.fai ", sub(".srf", ".sam", filen[i]), " ", sub(".srf", ".bam", filen[i]), " \n", sep="", file=f1)
      })
    close(f1)
    system(paste("qsub ", tname[length(tname)], ".sh", sep=""))
  }
  suma <- 1
  cat("\nWaiting for preocesses to finish...")
  while(suma>0) {
    Sys.sleep(300)
    suma <- sum(sapply(tname, function(x) length(system(paste("qstat -u ", system("whoami", intern=TRUE)," | grep ", x, sep=""), intern=TRUE))))
  }
  cat("\nCleaning-up...")
  tmp <- sapply(tname, function(x) file.remove(list.files(pattern=x)))
  file.remove(c(list.files(pattern="*.sam"), list.files(pattern="*.fa")))  
}

#' Summarizing BAM files at geneID level
#' 
#' This function launch parallel bam file summarization at geneID level
#' 
#' @param filen Vector of character strings indicating the name of the bam files, including extension
#' @param genome Character string indicating the genome to use
#' @param bychromosome Logical, whether the analysis should be performed iteratively for each chromosome. This approch takes much less memmory
#' @param prefix Character string indicating the prefix for the sequence name, sometimes it is chr
#' @param output Character string indicating the name of the output file 
#' @param dup Character string indicating whether to keep or remove the duplicate reads. If both, then 2 files with raw counts will be generated
#' @return Nothing, a discrete expression set is generated
#' @export

parallelBam <- function(filen, genome="mm9", output, prefix="", bychromosome=TRUE, dup=c("keep", "remove", "both")) {
    dup <- match.arg(dup)
    ofile <- paste("m", substr(as.vector(Sys.time()), 6, 10), sep="")
    tname <- NULL
    for (i in 1:length(filen)) {
        tname <- c(tname, paste(ofile, i, sep=""))
        f1 <- file(paste(tname[length(tname)], ".sh", sep=""), open="wt")
        cat("#!/bin/bash\n#\n#$ -cwd\n#$ -j y\n#$ -l mem=16G,time=4::\n#$ -S /bin/bash\n#$ -N ", tname[length(tname)], "\n", sep="", file=f1)
        cat("export R_LIBS_USER=/ifs/scratch/c2b2/ac_lab/malvarez/Rlib\nexport TMPDIR=/ifs/scratch/c2b2/ac_lab/malvarez/tmp\n", file=f1)
        cat("R CMD BATCH --no-save ", tname[length(tname)], ".r\n", sep="", file=f1)
        close(f1)
        f1 <- file(paste(tname[length(tname)], ".r", sep=""), open="wt")
        cat("library(GenomicFeatures)\nlibrary(Rsamtools)\nlibrary(GenomicAlignments)\n", sep="", file=f1)
        cat("load(\"/ifs/scratch/c2b2/ac_lab/malvarez/databases/genomes/", genome, "-gene.rda\")\n", sep="", file=f1)
        if (bychromosome) {
            cat("indexBam(\"", filen[i], "\")\n", sep="", file=f1)
            cat("sn <- scanBamHeader(\"", filen[i], "\")[[1]]$targets\n", sep="", file=f1)
            cat("res <- lapply(1:length(sn), function(i, sn, fn, tx) {\n", sep="", file=f1)
            cat("param <- ScanBamParam(which=GRanges(names(sn)[i], IRanges(1, sn[i])))\n", sep="", file=f1)
            cat("reads <- readGAlignmentsFromBam(fn, param=param)\n", sep="", file=f1)
            cat("reads <- GRanges(seqnames=paste(\"", prefix, "\", rname(reads), sep=\"\"), ranges=IRanges(start=start(reads), end=end(reads)), strand=rep(\"*\",length(reads)))\n", sep="", file=f1)
            cat("ureads <- reads[!duplicated(paste(start(reads), end(reads), sep=\"-\"))]\n", file=f1)
            cat("res <- countOverlaps(tx, reads)\nnames(res) <- names(tx)\n", file=f1)
            cat("res1 <- countOverlaps(tx, ureads)\nnames(res1) <- names(tx)\n", file=f1)
            cat("return(list(all=res, unique=res1))\n", sep="", file=f1)
            cat("}, sn=sn, fn=\"", filen[i], "\", tx=tx_by_gene)\n", sep="", file=f1)
            cat("res1 <- rowSums(sapply(res, function(x) x$unique))\nres <- rowSums(sapply(res, function(x) x$all))\n", file=f1)
            cat("file.remove(\"", filen[i], ".bai\")\n", sep="", file=f1)
        }
        else{
            cat("reads <- readGAlignmentsFromBam(\"", filen[i], "\")\n", sep="", file=f1)
            cat("reads <- GRanges(seqnames=paste(\"", prefix, "\", rname(reads), sep=\"\"), ranges=IRanges(start=start(reads), end=end(reads)), strand=rep(\"*\",length(reads)))\n", sep="", file=f1)
            cat("ureads <- reads[!duplicated(paste(unlist(as.list(seqnames(reads)), use.names=FALSE), start(reads), end(reads), sep=\"-\"))]\n", file=f1)
            cat("res <- countOverlaps(tx_by_gene, reads)\n", sep="", file=f1)
            cat("res1 <- countOverlaps(tx_by_gene, ureads)\n", file=f1)
            cat("names(res) <- names(res1) <- names(tx_by_gene)\n", sep="", file=f1)
        }
        cat("save(res, res1, file=\"", tname[length(tname)], ".exp\")\n", sep="", file=f1)
        close(f1)
        system(paste("qsub ", tname[length(tname)], ".sh", sep=""))
    }
    suma <- 1
    cat("\nWaiting for processes to finish...")
    while(suma>0) {
        Sys.sleep(300)
        suma <- sum(sapply(tname, function(x) length(system(paste("qstat -u ", system("whoami", intern=TRUE), " | grep ", x, sep=""), intern=TRUE))))
    }
    cat("\nIntegrating the summarized data...")
    tmp <- lapply(tname, function(x) {load(paste(x, ".exp", sep="")); list(res, res1)})
    genes <- table(unlist(lapply(tmp, function(x) names(x[[1]])), use.names=F))
    genes <- names(genes)[genes==length(tmp)]
    dset <- sapply(tmp, function(x, genes) x[[1]][match(genes, names(x[[1]]))], genes=genes)
    udset <- sapply(tmp, function(x, genes) x[[2]][match(genes, names(x[[2]]))], genes=genes)
    colnames(dset) <- colnames(udset) <- sub(".bam", "", filen)
    if (dup %in% c("keep", "both")) save(dset, file=paste(output, ".rda", sep=""))
    dset <- udset
    if (dup %in% c("remove", "both")) save(dset, file=paste(output, "-unique.rda", sep=""))
    cat("\nCleaning-up...")
    tmp <- sapply(tname, function(x) file.remove(list.files(pattern=x)))
}
