#' Outliers removal from shapiro normality test
#'
#' This function removes outliers using Shapiro-normality test method
#'
#' @param x Numerical vector
#' @param cutoff Threshold value for outlier detection
#' @return Outliers removed numerical vector
#' @export

outlier.shapiro <- function(x, cutoff=25) {
  med1 <- median(x)
  mad1 <- mad(x)
  den <- density(x, from=med1-mad1, to=med1+mad1)
  mode <- den$x[which.max(den$y)]
  x <- x-mode
  orden <- order(abs(x), decreasing=T)
  if (cutoff < 1) {
    pval <- shapiro.test(x[orden])$p.value
    while(pval < cutoff & length(orden)>3) {
      orden <- orden[-1]
      pval <- shapiro.test(x[orden])$p.value
    }
    if (length(orden)>3) return(sort(orden))
    warning("No outliers detected", call.=F)
    return(1:length(x))
  }
  res <- shapiro.test(x)$statistic
  for (i in 1:(length(orden)-3)) res <- c(res, shapiro.test(x[-orden[1:i]])$statistic)
  res <- order(res, decreasing=T)
  res <- res[res<length(x)*cutoff/100][1]
  return(sort(orden[res:length(orden)]))
}

#' Outliers removal using Grubbs test
#'
#' This function removes outliers detected with Grubbs' test
#'
#' @param x Numerical vector
#' @param cutoff P-value cutoff for outlier detection
#' @return Outliers removed numerical vector
#' @export

outlier.grubbs <- function(x, cutoff=.05) {
  require(outliers)
  x1 <- x
  pos <- which.max(abs(x-mean(x)))
  pval <- grubbs.test(x)$p.value
  while(pval < cutoff & length(x)>2) {
    x <- x[-pos]
    pos <- which.max(abs(x-mean(x)))
    pval <- grubbs.test(x)$p.value
  }
  if (length(x)>2) return(x)
  warning("No outlier detection possible", call.=F)
  return(x1)
}

