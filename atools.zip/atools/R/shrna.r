#' Integration of shRNA screen results
#'
#' This function integrates shRNA screen results across multiple hairpines using a MARINa approach
#'
#' @param x Named vector of results for a given sample, with hairpinID as names
#' @param annot Vector of gene annotation for the hairpines
#' @param score Number indicating the exponent score for the enrichment analysis
#' @return numeric vector of integrated results
#' @export

shRNAinteg <- function(x, annot, score=0) {
  x <- x[names(x) %in% names(annot)]
  annot <- annot[names(annot) %in% names(x)]
  x <- qnorm(rank(x)/(length(x) + 1))  
  gr <- split(names(annot), annot)
  cat("\nComputing integration score for ", length(gr), " traits.\n", sep="")
  cat("Process started at ", date(), "\n", sep="")
  assign("i", 1, envir=as.environment(".GlobalEnv"))
  assign("total", length(gr), envir=as.environment(".GlobalEnv"))
  assign("c10", 10, envir=as.environment(".GlobalEnv"))
  assign("c2", 2, envir=as.environment(".GlobalEnv"))
  nis <- sapply(gr, function(ii, x, score) {
    pos <- match(ii, names(x))
    w <- abs(x[pos])^score
    is <- sum(x[pos]*w/sum(w))
    sigma <- sqrt(sum((w/sum(w))^2))
    total <- get("total", envir=as.environment(".GlobalEnv"))
    i <- get("i", envir=as.environment(".GlobalEnv"))
    c10 <- get("c10", envir=as.environment(".GlobalEnv"))
    c2 <- get("c2", envir=as.environment(".GlobalEnv"))
    if (i*100/total > c2) {cat("."); assign("c2", c2 + 2, envir=as.environment(".GlobalEnv"))}
    if (i*100/total >= c10) {cat(c10, "%", sep=""); assign("c10", c10 + 10, envir=as.environment(".GlobalEnv"))}
    assign("i", i+1, envir=as.environment(".GlobalEnv"))
    return(is/sigma)
  }, x=x, score=score)
  return(nis)
}

