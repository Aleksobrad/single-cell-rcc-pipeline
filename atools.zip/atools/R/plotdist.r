#' violin
#' 
#' Plot density distributions using a violin plot
#' 
#' @param data List or matrix containing the univariate distributions to plot
#' @param col Vector of fill colors
#' @param border Vector of line colors for the violin borders
#' @param trim Logical, whether the density estimation should be trimmed to match the data
#' @param scaled Logical, whether each density distribution should be scaled
#' @param adjust Number indicating the adjust parameter for the density estimation
#' @param axes Logical, whether plot axis should be added
#' @param ylim Optional vector of two elements indicating the limits for the y axis
#' @param add Logical, whether the plot should be added on top of hte current default plot
#' @param lty Number indicating the style for the violin border
#' @param lwd Number indicating the width for the violin border
#' @param hline optional vector indicating the horizontal positions to add lines to the plot
#' @param center optional character string indicating the type of center statistic to plot, either mean, median or mode
#' @param horiz Logical, whether the plot should be horizontal
#' @return Nothing, a violin plot is created in the default output device
#' @export

violin <- function(data, col="grey", border="black", trim=TRUE, scaled=TRUE, adjust=1, axes=TRUE, ylim=NULL, add=FALSE, lty=1, lwd=1, hline=NULL, center=c("none", "mean", "median", "mode"), horiz=FALSE) {
    center <- match.arg(center)
    if (is(data, "matrix")) {
        den <- apply(data, 2, function(x, adjust, trim) {
            if (trim) return(density(x, adjust=adjust, from=max(min(x, na.rm=TRUE), ylim[1]), to=min(max(x, na.rm=TRUE), ylim[2]), na.rm=TRUE))
            return(density(x, adjust=adjust, na.rm=TRUE))
        }, adjust=adjust, trim=trim)
    }
    else if (is.list(data)) {
        den <- lapply(data, function(x, adjust, trim) {
            if (length(x)==1) return(NA)
            if (trim) return(density(x, adjust=adjust, from=max(min(x, na.rm=TRUE), ylim[1]), to=min(max(x, na.rm=TRUE), ylim[2]), na.rm=TRUE))
            return(density(x, adjust=adjust, na.rm=TRUE))
        }, adjust=adjust, trim=trim)
    }
    else stop("data must be a list or matrix", call.=FALSE)
    if (scaled) {
        den <- lapply(den, function(x) {
            if (length(x)<3) return(NA)
            x$y <- x$y/max(x$y, na.rm=TRUE)
            return(x)
        })
    }
    if (is.null(ylim)) {
        ylim <- sapply(den, function(x) {
            if (length(x)<3) return(c(0, 0))
            range(x$x, na.rm=TRUE)
        })
        ylim <- c(min(ylim[1, ]), max(ylim[2, ]))
    }
    den <- lapply(den, function(x, top) {
        if (length(x)<3) return(NA)
        x$y <- x$y/top*.45
        return(x)
    }, top=max(sapply(den, function(x) {
        if (length(x)<3) return(NA)
        max(x$y, na.rm=TRUE)
    }), na.rm=TRUE))
    if (is(data, "matrix")) {
        switch(center,
               none={center <- NULL},
               mean={center <- colMeans(data, na.rm=TRUE)},
               median={center <- apply(data, 2, median, na.rm=TRUE)}, 
               mode={center <- apply(data, 2, distMode)})
    }
    else {
        switch(center,
               none={center <- NULL},
               mean={center <- sapply(data, mean, na.rm=TRUE)},
               median={center <- sapply(data, median, na.rm=TRUE)}, 
               mode={center <- sapply(data, distMode)})
    }    
    if (!add) plot.new()
    if (horiz) {
        plot.window(ylim=c(.5, length(den)+.5), xlim=ylim)
        if (axes) {
            axis(1)
            axis(2, 1:length(den), names(den), las=2)
            box()
        }
        if (length(col)<length(den)) col <- rep(col[1], length(den))
        if (length(border)<length(den)) border <- rep(border[1], length(den))
        if (!is.null(hline)) abline(h=hline)
        for (i in 1:length(den)) {
            if (length(den[[i]])>2) polygon(c(den[[i]]$x, rev(den[[i]]$x)), c(i+den[[i]]$y, i-rev(den[[i]]$y)), col=col[i], border=border[i], lty=lty, lwd=lwd)
        }
        if (length(center)>0) {
            for (i in 1:length(center)) {
                if (length(den[[i]])>2) {
                    ll <- approx(den[[i]]$x, den[[i]]$y, xout=center[i])$y
                    lines(rep(center[i], 2), c(i-ll*.9, i+ll*.9))
                }
            }
        }        
    }
    else {
        plot.window(xlim=c(.5, length(den)+.5), ylim=ylim)
        if (axes) {
            axis(2)
            axis(1, 1:length(den), names(den), las=2)
            box()
        }
        if (length(col)<length(den)) col <- rep(col[1], length(den))
        if (length(border)<length(den)) border <- rep(border[1], length(den))
        if (!is.null(hline)) abline(h=hline)
        for (i in 1:length(den)) {
            if (length(den[[i]])>2) polygon(c(i+den[[i]]$y, i-rev(den[[i]]$y)), c(den[[i]]$x, rev(den[[i]]$x)), col=col[i], border=border[i], lty=lty, lwd=lwd)
        }
        if (length(center)>0) {
            for (i in 1:length(center)) {
                if (length(den[[i]])>2) {
                    ll <- approx(den[[i]]$x, den[[i]]$y, xout=center[i])$y
                    lines(c(i-ll*.9, i+ll*.9), rep(center[i], 2))
                }
            }
        }
    }
}

#' violin2
#' 
#' Plot density distributions using a violin plot for paired data
#' 
#' @param data List containing the univariate distributions to plot
#' @param col Vector of fill colors
#' @param border Vector of line colors for the violin borders
#' @param trim Logical, whether the density estimation should be trimmed to match the data
#' @param scaled Logical, whether each density distribution should be scaled
#' @param adjust Number indicating the adjust parameter for the density estimation
#' @param axes Logical, whether plot axis should be added
#' @param ylim Optional vector of two elements indicating the limits for the y axis
#' @param add Logical, whether the plot should be added on top of hte current default plot
#' @param lty Number indicating the style for the violin border
#' @param lwd Number indicating the width for the violin border
#' @param hline optional vector indicating the horizontal positions to add lines to the plot
#' @param center optional character string indicating the type of center statistic to plot, either mean, median or mode
#' @param horiz Logical, whether the plot must be horizontal
#' @return Nothing, a violin plot is created in the default output device
#' @examples
#' data <- list(list(rnorm(100, 3), rnorm(150, 1)), list(rnorm(50,3), rnorm(100, 3)))
#' violin2(data, center="median", col=hsv(c(.1, .4, .1, .4), .5, .8))
#' @export

violin2 <- function(data, col="grey", border="black", trim=TRUE, scaled=TRUE, adjust=1, axes=TRUE, ylim=NULL, add=FALSE, lty=1, lwd=1, hline=NULL, center=c("none", "mean", "median", "mode"), horiz=FALSE) {
    center <- match.arg(center)
    if (!is(data, "list")) stop("Data must be a list", call.=FALSE)
    den <- lapply(data, function(x, adjust, trim, center) {
        if (is(x, "list")) {
            if (length(x)>2) x <- x[1:2]
            den <- lapply(x, function(x, adjust, trim, center) {
                if (length(x)==1) return(NA)
                if (trim) den <- density(x, adjust=adjust, from=max(min(x), ylim[1]), to=min(max(x), ylim[2]), na.rm=TRUE)
                else den <- density(x, adjust=adjust, na.rm=TRUE)
                switch(center,
                       none={center <- NULL},
                       mean={center <- mean(x, na.rm=TRUE)},
                       median={center <- median(x, na.rm=TRUE)}, 
                       mode={center <- distMode(x)})
                den$center <- center
                return(den)
            }, adjust=adjust, trim=trim, center=center)
            return(den)
        }
        if (length(x)<3) return(NA)
        if (is.null(ncol(x))) x <- matrix(x, length(data), 1, dimnames=list(names(x), NULL))
        if (ncol(x)>2) x <- x[, 1:2]
        den <- apply(x, 2, function(x, adjust, trim, center) {
            if (trim) den <- density(x, adjust=adjust, from=max(min(x), ylim[1]), to=min(max(x), ylim[2]), na.rm=TRUE)
            else den <- density(x, adjust=adjust, na.rm=TRUE)
            switch(center,
                   none={center <- NULL},
                   mean={center <- mean(x, na.rm=TRUE)},
                   median={center <- median(x, na.rm=TRUE)}, 
                   mode={center <- distMode(x)})
            den$center <- center            
            return(den)
        }, adjust=adjust, trim=trim, center=center)
        return(den)
    }, adjust=adjust, trim=trim, center=center)
    if (scaled) {
        den <- lapply(den, function(x) {
            lapply(x, function(x) {
                if (length(x)<3) return(NA)
                x$y <- x$y/max(x$y)
                return(x)
            })
        })
    }
    if (is.null(ylim)) {
        ylim <- sapply(unlist(den, recursive=FALSE, use.names=FALSE), function(x) {
            if (length(x)<3) return(c(0, 0))
            range(x$x)
        })
        ylim <- c(min(ylim[1, ]), max(ylim[2, ]))
    }
    den <- lapply(den, function(x, top) {
        lapply(x, function(x, top) {
            if (length(x)<3) return(NA)
            x$y <- x$y/top*.45
            return(x)
        }, top=top)
    }, top=max(sapply(unlist(den, recursive=FALSE, use.names=FALSE), function(x) {
        if (length(x)<3) return(0)
        max(x$y)
    })))
    if (!add) plot.new()
    if (horiz) {
        plot.window(ylim=c(.5, length(den)+.5), xlim=ylim)
        if (axes) {
            axis(1)
            axis(2, 1:length(den), names(den), las=2)
            box()
        }
        if (length(col)<(2*length(den))) col <- rep(col[1], 2*length(den))
        if (length(border)<length(den)) border <- rep(border[1], length(den))
        if (!is.null(hline)) abline(h=hline)
        for (i in 1:length(den)) {
            if (length(den[[i]][[1]])>1) {
                polygon(c(den[[i]][[1]]$x[1], den[[i]][[1]]$x, den[[i]][[1]]$x[length(den[[i]][[1]]$x)]), c(i, i-den[[i]][[1]]$y, i), col=col[(i-1)*2+1], border=border[i], lty=lty, lwd=lwd)
                if (!is.null(den[[i]][[1]]$center)) {
                    ll <- approx(den[[i]][[1]]$x, den[[i]][[1]]$y, xout=den[[i]][[1]]$center)$y*.9
                    lines(rep(den[[i]][[1]]$center, 2), c(i-ll, i), lwd=lwd*1.5)
                }
            }
            if (length(den[[i]])>1) {
                if (length(den[[i]][[2]])>1) {
                    polygon(c(den[[i]][[2]]$x[1], den[[i]][[2]]$x, den[[i]][[2]]$x[length(den[[i]][[2]]$x)]), c(i, i+den[[i]][[2]]$y, i), col=col[(i-1)*2+2], border=border[i], lty=lty, lwd=lwd)
                    if (!is.null(den[[i]][[2]]$center)) {
                        ll <- approx(den[[i]][[2]]$x, den[[i]][[2]]$y, xout=den[[i]][[2]]$center)$y*.9
                        lines(rep(den[[i]][[2]]$center, 2), c(i+ll, i), lwd=lwd*1.5)
                    }
                }
            }
        }
    }
    else {
        plot.window(xlim=c(.5, length(den)+.5), ylim=ylim)
        if (axes) {
            axis(2)
            axis(1, 1:length(den), names(den), las=2)
            box()
        }
        if (length(col)<(2*length(den))) col <- rep(col[1], 2*length(den))
        if (length(border)<length(den)) border <- rep(border[1], length(den))
        if (!is.null(hline)) abline(h=hline)
        for (i in 1:length(den)) {
            if (length(den[[i]][[1]])>1) {
                polygon(c(i, i-den[[i]][[1]]$y, i), c(den[[i]][[1]]$x[1], den[[i]][[1]]$x, den[[i]][[1]]$x[length(den[[i]][[1]]$x)]), col=col[(i-1)*2+1], border=border[i], lty=lty, lwd=lwd)
                if (!is.null(den[[i]][[1]]$center)) {
                    ll <- approx(den[[i]][[1]]$x, den[[i]][[1]]$y, xout=den[[i]][[1]]$center)$y*.9
                    lines(c(i-ll, i), rep(den[[i]][[1]]$center, 2), lwd=lwd*1.5)
                }
            }
            if (length(den[[i]])>1) {
                if (length(den[[i]][[2]])>1) {
                    polygon(c(i, i+den[[i]][[2]]$y, i), c(den[[i]][[2]]$x[1], den[[i]][[2]]$x, den[[i]][[2]]$x[length(den[[i]][[2]]$x)]), col=col[(i-1)*2+2], border=border[i], lty=lty, lwd=lwd)
                    if (!is.null(den[[i]][[2]]$center)) {
                        ll <- approx(den[[i]][[2]]$x, den[[i]][[2]]$y, xout=den[[i]][[2]]$center)$y*.9
                        lines(c(i+ll, i), rep(den[[i]][[2]]$center, 2), lwd=lwd*1.5)
                    }    
                }
            }
        }
    }
}

#' boxline
#' 
#' Box-and-whisker plot using lines for the columns of an input matrix
#' 
#' @param y Numeric matrix, its columns will be used for the box-whisker plot
#' @param x Optional numeric vector for the x-coordinates
#' @param color Either character string indicating the color for the plot or number between 0 and 1 indicating the hue for the color
#' @param ylim Optional y-axis limits
#' @param smooth Numbre indicating the smoothnes of the lines, 0 for no smooth
#' @param outline Logical, whether outliers should be plot
#' @param border Logical, whenter to dray the borders for the box and whisker
#' @param pch Integer indicating the type of point for the outliers
#' @param ... Additional parameters passed to plot
#' @return Nothing, a plot is generated in the default output device
#' @export

boxline <- function(y, x=NULL, color="cornflowerblue", ylim=NULL, smooth=0, outline=TRUE, border=FALSE, pch=20, ...) {
    if (!is.numeric(color)) {
        color <- col2rgb(color)
        color <- rgb2hsv(color[1], color[2], color[3])[1]
    }
    if (is.null(x)) x <- 1:ncol(y)
    pos <- order(x)
    x <- x[pos]
    y <- y[, pos]
    bwp <- apply(y, 2, function(x) {
        qt <- quantile(x, c(.25, .5, .75), na.rm=TRUE)
        wr <- c(qt[1]-(qt[3]-qt[1]), qt[3]+(qt[3]-qt[1]))
        bw <- c(min(x[x>wr[1]], na.rm=TRUE), max(x[x<wr[2]], na.rm=TRUE))
        out <- c(x[x<bw[1]], x[x>bw[2]])
        list(bw=c(bw[1], qt, bw[2]), out=out)
    })
    if (is.null(ylim)) ylim <- range(unlist(bwp, use.names=FALSE), na.rm=TRUE)
    plot(0, 0, type="n", xlim=range(x), ylim=ylim, ...)
    bw <- t(sapply(bwp, function(x) x$bw))
    bw <- apply(bw, 2, function(x, xx, smooth) smooth.spline(xx, x, spar=smooth)$y, xx=x, smooth=smooth)
    if (border) {
        polygon(c(x, rev(x)), c(bw[, 1], rev(bw[, 5])), border=hsv(color, .3, .5), col=hsv(color, .2, .9))
        polygon(c(x, rev(x)), c(bw[,2], rev(bw[, 4])), border=hsv(color, .7, .5), col=hsv(color, .6, .8))
    }
    else {
        polygon(c(x, rev(x)), c(bw[, 1], rev(bw[, 5])), border=NA, col=hsv(color, .2, .9))
        polygon(c(x, rev(x)), c(bw[,2], rev(bw[, 4])), border=NA, col=hsv(color, .6, .8))
    }
    lines(x, bw[, 3], lwd=2)
    if (outline) points(rep(x, sapply(bwp, function(x) length(x$out))), unlist(lapply(bwp, function(x) x$out), use.names=FALSE), pch=pch)
}

#' densityPlot
#' 
#' Plot density distributions using polygons
#' 
#' @param data List or matrix containing the univariate distributions to plot
#' @param col Vector of fill colors
#' @param border Vector of line colors for the violin borders
#' @param trim Logical, whether the density estimation should be trimmed to match the data
#' @param scaled Logical, whether the height of the density curved should be scaled
#' @param adjust Number seting the adjust parameter for the density estimation
#' @param axes Logical, whether plot axis should be added
#' @param lty Optional style for the border
#' @param xlim Optional vector of two elements indicating the limits for the x axis
#' @param add Logical, whether the plot should be added on top of the current default plot
#' @param lwd Number indicating the width for the border
#' @param vline Optional vector indicating the vertical positions to add lines to the plot
#' @param alpha Optional transparency value between 0 and 1
#' @return Nothing, a violin plot is created in the default output device
#' @export

densityPlot <- function(data, col=hsv(0, .6, .2, .5), border="black", trim=TRUE, scaled=FALSE, adjust=1, axes=TRUE, xlim=NULL, add=FALSE, lty=1, lwd=1, vline=NULL) {
    if (is(data, "matrix")) {
        den <- apply(data, 2, function(x, adjust, trim) {
            if (trim) return(density(x, adjust=adjust, from=min(x, na.rm=TRUE), to=max(x, na.rm=TRUE), na.rm=TRUE))
            return(density(x, adjust=adjust, na.rm=TRUE))
        }, adjust=adjust, trim=trim)
    }
    else if (is(data, "list")) {
        den <- lapply(data, function(x, adjust, trim) {
            if (trim) return(density(x, adjust=adjust, from=min(x, na.rm=TRUE), to=max(x, na.rm=TRUE), na.rm=TRUE))
            return(density(x, adjust=adjust, na.rm=TRUE))
        }, adjust=adjust, trim=trim)
    }
    else stop("data must be a list or matrix", call.=FALSE)
    if (scaled) {
        den <- lapply(den, function(x) {
            x$y <- x$y/max(x$y)
            return(x)
        })
    }
    if (is.null(xlim)) {
        xlim <- sapply(den, function(x) range(x$x))
        xlim <- c(min(xlim[1, ]), max(xlim[2, ]))
    }
    ylim <- c(0, max(sapply(den, function(x) max(x$y))))
    if (!add) plot.new()
    plot.window(xlim=xlim, ylim=ylim)
    if (axes) {
        axis(2)
        axis(1)
        box()
    }
    if (length(col)<length(den)) col <- rep(col[1], length(den))
    if (length(border)<length(den)) border <- rep(border[1], length(den))
    if (length(lty)<length(den)) lty <- rep(lty[1], length(den))
    if (length(lwd)<length(den)) lwd <- rep(lwd[1], length(den))
    if (!is.null(vline)) abline(v=vline)
    for (i in 1:length(den)) {
        polygon(c(min(den[[i]]$x), den[[i]]$x, max(den[[i]]$x)), c(0, den[[i]]$y, 0), col=col[i], border=border[i], lty=lty[i], lwd=lwd[i])
    }
}


    