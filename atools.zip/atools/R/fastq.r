#' Remove redundant sequences from fastq files
#' 
#' This function remove repeated sequences from fastq files derived from sorted bam files
#' 
#' @param input Character string indicating the name of the input fastq file
#' @param output Character string indicating the name of the output fastq file
#' @return Nothing, a filtered fastq file is produced
#' @export
cleanSortedFastq <- function(input, output) {
  ifile <- file(paste(input, ".fastq", sep=""), open="rt")
  ofile <- file(paste(output, ".fastq", sep=""), open="wt")
  prev <- "NULL"
  tmp <- readLines(ifile, n=4)
  while (length(tmp)==4) {
    if (tmp[[1]]!=prev) {
      cat(tmp, sep="\n", file=ofile)
      prev <- tmp[[1]]
    }
    tmp <- readLines(ifile, n=4)
  }
  close(ifile)
  close(ofile)
}

#' bam to fastq conversion
#' 
#' This function converts a set of bam files into non-redundant fastq files using the titan cluster
#' 
#' @param fnames Vector of character strings indicating the bam file names
#' @return Nothing, fastq files are generated
#' @export
bam2fastq <- function(fnames=NULL) {
  if (is.null(fnames)) fnames <- list.files(pattern=".bam")
  fnames <- fnames[fnames %in% dir()]
  tmp <- sapply(fnames, function(x) {
    cat("#!/bin/bash
#
#$ -cwd
#$ -j y
#$ -l mem=8G,time=4::
#$ -S /bin/bash
#$ -N a", gsub(".bam", "", x), "
#
samtools sort ", x, " ", gsub(".bam", "", x), ".sorted
bam2fastq --no-unaligned -o ", gsub(".bam", "", x), ".sorted.fastq ", x, "
export R_LIBS_USER=/ifs/scratch/c2b2/ac_lab/malvarez/Rlib
export TMP=/ifs/scratch/c2b2/ac_lab/malvarez/aracnetmp
/nfs/apps/R/2.14.0/bin/R CMD BATCH --no-save a", x, ".r", sep="", file=paste("a", x, ".sh", sep=""))
    cat("library(atools)
cleanSortedFastq(\"", gsub(".bam", "", x), ".sorted\", \"", gsub(".bam", "", x), "\")
", sep="", file=paste("a", x, ".r", sep=""))
    system(paste("qsub a", x, ".sh", sep=""))
  })
}
