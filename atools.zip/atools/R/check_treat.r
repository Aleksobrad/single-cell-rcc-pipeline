#Check if there is more than 1 treatment

check.treat <- function(expset) {
  if (names(expset)[1]=="expset") expset <- check.treat.i(expset)
  else expset <- lapply(expset,check.treat)
  expset
}

check.treat.i <- function(expset) {
  treat <- unique(expset$treat[!(expset$treat %in% expset$ctrl)])
  if (length(treat)>1) {
    expset <- lapply(treat,function(trat,expset) {
      filtro <- which(expset$treat %in% c(trat,expset$ctrl))
      expset$expset <- expset$expset[,filtro]
      if (!is.null(expset$qs)) expset$qs <- expset$qs[,filtro]
      expset$treat <- expset$treat[filtro]
      expset$group <- lapply(expset$group,function(x,filtro) x[filtro], filtro=filtro)
      expset[names(expset) != "go"]
    },expset=expset)
    names(expset) <- treat
  }
  expset
}
