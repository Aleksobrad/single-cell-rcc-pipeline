#Heatmaps of matrixes

plothm. <- function(x, color=c("royalblue","firebrick2"), gama=1, grid=T, scmax=0, box=TRUE, ...) {
    coli <- colorScale(x=filterRowMatrix(x, nrow(x):1), color=color, gama=gama, scmax=scmax)
    image(1:ncol(x), 1:nrow(x), t(matrix(1:(ncol(x)*nrow(x)), nrow(x), ncol(x))), col=coli, ylab="", xlab="", axes=F, ...)
    if (box) box()
    if (grid) grid(ncol(x), nrow(x), col="black", lty=1)
}

#' Plot heatmap
#'
#' This function produce a heatmap plot from a numerical matrix
#'
#' @param x Numerical matrix
#' @param color Two character strings vector describing the colors for the heatmap
#' @param gama Number, indicating the exponential transformation for the color scale
#' @param cex Number indicating the magnification factor for the labels
#' @param grid Logical, whether a grid should be ploted
#' @param scale Number between 0 and .9 indicating the proportion of vertical space used to draw the color scale
#' @param scmax Optional number indicating the maximum value to be allowed for the heatmap
#' @param box Logical, whether to draw a box around the plot
#' @param ... Additional parameters to pass to the plot function
#' @return Nothing, a heatmap is produced in the default output device
#' @export

plothm <- function(x, color=c("royalblue","firebrick2"), gama=1, cex=1, grid=T, scale=F, scmax=0, box=TRUE, ...) {
    if (scale>0) {
        if (scale==1) ff <- 6/(nrow(x)+5)
        else ff <- scale
        pari <- par("mai")
        layout(matrix(1:2, 2, 1), h=c(1-ff, ff))
        if (round(sum(pari-c(1.02, .82, .82, .42)), 2)==0) pari <- c(.2, .2, 1.2, 1.2)
        par(mai=pari)
        plothm.(x, color=color, gama=gama, scmax=scmax, box=box, ...)
        axis(4, nrow(x):1, rownames(x), tick=F, line=0, las=2, adj=0, cex.axis=cex)
        axis(3, 1:ncol(x), colnames(x), tick=F, line=0, las=2, adj=0, cex.axis=cex)
        ra <- seq(-1, 1, length=100)
        coli <- colorScale(x=ra, color=color, gama=gama, scmax=scmax)
        par(mai=pari*c(0, 1, 0, 3)+c(.5, 0, .1, 0))
        image(1:length(ra), 1, matrix(1:length(ra), length(ra), 1), col = coli, ylab = "", xlab = "", axes = F)
        if (scmax==0) scmax <- max(abs(x), na.rm=T)
        axis(1, seq(1, length(ra), length=5), round(seq(-scmax, scmax, length=5), 1), cex.axis=cex)
    }
    else plothm.(x=x, color=color, gama=gama, grid=grid, scmax=scmax, box=box, ...)
}

#' plothmDendro
#'
#' This function produce heatmap with dendrograms
#'
#' @param x Numeric matrix to be represented in the dendrogram
#' @param hclass Optional vector of horizontal classes
#' @param vclass Optional vector of vertical classes
#' @param hdendro Optional horizontal dendrogram
#' @param vdendro Optional vertical dendrogram
#' @param color Two elements vector indicating the colors
#' @param gama Number indicating the gama exponent for the color scale
#' @param cex Number indicating the labels magnification factor for y, x and scale axis
#' @param grid Logical, whether a grid should be ploted
#' @param scmax Optional maximum value for the color scale
#' @param lines List indicating the horizontal and vertical positions to include lines
#' @param hcol Optional vector of colors for the horizontal classes
#' @param vcol Optional vector of colors for the vertical classes
#' @return Nothing, a plot is created in the default output device
#' @export

plothmDendro <- function(x, hclass=NULL, vclass=NULL, hdendro=NULL, vdendro=NULL, color=c("royalblue", "firebrick2"), gama=1, cex=1, grid=T, scmax=0, lines=list(h=NULL, v=NULL), hcol=NULL, vcol=NULL) {
	if (length(cex) != 3) cex <- rep(cex[1], 3)
	pari <- par("mai")
	ds <- dev.size()
	layout(matrix(1:6, 3, 2), h=c(1/ds[2], (ds[2]-2)/ds[2], 1/ds[2]), w=c(1/ds[1], (ds[1]-1)/ds[1]))
	par(mai=rep(.1, 4))
	plot(0, 0, type="n", axes=F, xlab="", ylab="")
	if (round(sum(pari-c(1.02, .82, .82, .42)), 2)==0) pari <- c(1.2, .01, .01, 1.2)
# vertical dendrogram
	tmp <- pari
	tmp[c(2, 4)] <- c(.1, pari[2])
	par(mai=tmp)
	lim <- c(0, length(vdendro$height)+1)+.5
	if (!is.null(hclass)) lim[2] <- lim[2]+1
	if (!is.null(vdendro)) {
		plot(as.dendrogram(vdendro), horiz=T, yaxs="i", leaflab="none", axes=F, ylim=lim)
		x <- x[vdendro$order, ]
		if (!is.null(vclass)) vclass <- vclass[vdendro$order]
	}
	else plot(0, 0, type="n", axes=F, xlab="", ylab="")
	par(mai=rep(.1, 4))
	plot(0, 0, type="n", axes=F, xlab="", ylab="")
#horiz dendrogram
	tmp <- pari
	tmp[c(1, 3)] <- c(pari[3], .1)
	par(mai=tmp)
	lim <- c(0, length(hdendro$height)+1)+.5
	if (!is.null(vclass)) lim[2] <- lim[2]+1
	if (!is.null(hdendro)) {
		plot(as.dendrogram(hdendro), horiz=F, xaxs="i", leaflab="none", axes=F, xlim=lim)
		x <- x[, hdendro$order]
		if (!is.null(hclass)) hclass <- hclass[hdendro$order]
	}
	else 	plot(0, 0, type="n", axes=F, xlab="", ylab="")
#heatmap
	par(mai=pari)
	if (scmax==0) scmax <- max(abs(x), na.rm=T)
  x <- abs(x/scmax)^gama*sign(x)
  color <- rgb2hsv(col2rgb(color))
  satval <- color[3,]
  color <- color[1,]
  x1 <- x
  x1[is.na(x1)] <- 0
  coli <- hsv(ifelse(x1<0, color[1], color[2]), abs(x1), 1)
  coli[is.na(x)] <- hsv(0, 0, .5)
  zz <- matrix(1:(ncol(x)*nrow(x)), nrow(x), ncol(x))
  if (!is.null(hclass)) {
		zz <- rbind(zz, max(zz) + match(hclass, sort(unique(hclass))))
        col1 <- colores(length(unique(hclass)), end=.7)
        if (!is.null(hcol)) {
            if (length(hcol)==length(unique(hclass))) {
                col1 <- hcol
            }
        }
		coli <- c(coli, col1)
		lines$h <- c(lines$h, nrow(x)+.5)
	}
	if (!is.null(vclass)) {
        col1 <- colores(length(unique(vclass)), end=.7)
        if (!is.null(vcol)) {
            if (length(vcol)==length(unique(vclass))) {
            col1 <- vcol
            }
        }
        if (is.null(hclass)) {
			zz <- cbind(zz, max(zz) + match(vclass, sort(unique(vclass))))
			coli <- c(coli, col1)
		}
		else {
			zz <- cbind(zz, max(zz) + c(match(vclass, sort(unique(vclass))), 0)+1)
			coli <- c(coli, hsv(0, 0, 1), col1)	
		}
		lines$v <- c(lines$v, ncol(x)+.5)
	}
  image(1:ncol(zz), 1:nrow(zz), t(zz), col=coli, ylab="", xlab="", axes=F)
	abline(v=lines$v, h=lines$h, lwd=cex[1]*2)
  box()
  if (grid) grid(ncol(zz), nrow(zz), col="black", lty=1)
	axis(4, 1:nrow(x), rownames(x), tick=F, line=0, las=2, adj=0, cex.axis=cex[1])
	axis(1, 1:ncol(x), colnames(x), tick=F, line=0, las=2, adj=0, cex.axis=cex[2])
#scalebar
	ra <- seq(-1, 1, length=100)
	ra <- sign(ra)*abs(ra)^gama
	coli <- hsv(ifelse(ra < 0, color[1], color[2]), abs(ra), 1)
	tmp <- pari
	tmp[c(1, 3)] <- c(.4, .2)
	par(mai=tmp)
	image(1:length(ra), 1, matrix(1:length(ra), length(ra), 1), col = coli, ylab = "", xlab = "", axes = F)
	if (scmax==0) scmax <- max(abs(x), na.rm=T)
	axis(1, seq(1, length(ra), length=5), round(seq(-scmax, scmax, length=5), 1), cex.axis=cex[3])
}

#' colores
#' 
#' This function generates a table of colors useful for plot legends
#' 
#' @param nn Integer, number of categories for which different colors are required
#' @export
colores <- function(nn, start=0, end=.9) {
  if (nn>9) {
    n1 <- ceiling(nn/3)
    h <- seq(start, end, length=n1)
    tmp <- hsv(rep(h, 3), c(rep(1, 2*n1), rep(.4, n1)), c(rep(1, n1), rep(.7, n1), rep(1, n1)))
    return(tmp[1:nn])
  }
  rainbow(nn, 1, .9, start=start, end=end)
}
