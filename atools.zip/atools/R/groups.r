#' Length.na for groups
#'
#' This function computes the length of non-missing data by rows for \code{colnames}-defined groups
#'
#' @param dset Matrix
#' @return Matrix of integers
#' @export

lengthGroup <- function(dset) {
  groups <- colnames(dset)
  res <- NULL
  glev <- unique(groups)
  for (i in 1:length(glev)) res <- cbind(res,apply(as.matrix(dset[,groups==glev[i]]),1,lengthna))
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Median for groups
#'
#' This function computes the median for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

medianGroup <- function(dset) {
  groups <- colnames(dset)
  glev <- unique(groups)
  repit <- tapply(groups, groups, length)
  res <- dset[, match(names(repit)[repit==1], colnames(dset))]
  for (i in names(repit)[repit>1]) res <- cbind(res, rowMedians(dset[, groups==i]))
  res <- res[, match(glev, c(names(repit)[repit==1], names(repit)[repit>1]))]
  if (is.null(dim(res))) dim(res) <- c(length(res),1)
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Mean for groups
#'
#' This function computes the mean for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

meanGroup <- function(dset) {
  groups <- colnames(dset)
  glev <- unique(groups)
  repit <- tapply(groups, groups, length)
  res <- dset[,match(names(repit)[repit==1],colnames(dset))]
  for (i in names(repit)[repit>1]) res <- cbind(res,as.matrix(rmean(as.matrix(dset[,groups==i]))))
  res <- res[,match(glev,c(names(repit)[repit==1],names(repit)[repit>1]))]
  if (is.null(dim(res))) dim(res) <- c(length(res),1)
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Sum for groups
#'
#' This function computes the sum for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

sumGroup <- function(dset) {
  groups <- colnames(dset)
  glev <- unique(groups)
  repit <- tapply(groups, groups, length)
  res <- dset[,match(names(repit)[repit==1],colnames(dset))]
  for (i in names(repit)[repit>1]) res <- cbind(res,as.matrix(rsum(as.matrix(dset[,groups==i]))))
  res <- res[,match(glev,c(names(repit)[repit==1],names(repit)[repit>1]))]
  if (is.null(dim(res))) dim(res) <- c(length(res),1)
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Standard deviation for groups
#'
#' This function computes the SD for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

sdGroup <- function(dset) {
  groups <- colnames(dset)
  res <- NULL
  glev <- unique(groups)
  for (i in 1:length(glev)) res <- cbind(res,as.matrix(sqrt(rvar(matrix(dset[,groups==glev[i]],nrow(dset),length(which(groups==glev[i])))))))
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Maximum for groups
#'
#' This function computes the maximum value for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

maxGroup <- function(dset) {
  groups <- colnames(dset)
  res <- NULL
  glev <- unique(groups)
  for (i in 1:length(glev)) res <- cbind(res,apply(as.matrix(dset[,groups==glev[i]]),1,max,na.rm=T))
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Median absolute deviation for groups
#'
#' This function computes the MAD for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

madGroup <- function(dset) {
  groups <- colnames(dset)
  res <- NULL
  glev <- unique(groups)
  for (i in 1:length(glev)) res <- cbind(res,apply(as.matrix(dset[,groups==glev[i]]),1,mad,na.rm=T))
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

# Correlation analysis for groups
correlGroup <- function(dset,template,method=c("pearson","kendall","spearman")[1]) {
  t <- template[match(colnames(dset),names(template))]
  co <- apply(dset,1,cor,y=t,use="pairwise.complete.obs",method=method)
  cop <- apply(dset,1,cor.test,y=t,alternative="two.sided",method=method,use="pairwise.complete.obs")
  cop <- sapply(cop,function(x) x$p.value)
  list(r=co,p.value=cop)
}

