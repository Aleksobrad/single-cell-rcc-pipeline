#' enrichmentPlot
#' 
#' Generates bar-code like plots to show enrichment of a set of features on a signature
#' 
#' @param signature Vector of character strings indicating the IDs of the elements in the signature
#' @param regulon List of vectors containing the IDs of the elements of the signature to highlight
#' @param col Character string indicating the color for the barcode plot
#' @param bins Number indicating the number of elements per bin to smooth. Default to 1/20 of the signature length
#' @param offset Number between 0 and 0.5 indicating the separation between sets
#' @param sep Character string indicating the type of separation between sets, either box, line or none
#' @param ... Additional graphic paramiters to pass to the plot function
#' @description This function generates a barcode-like plot based on the signature. This function does not sort the signature, it has to be sorted before passing it to this function.
#' @export

enrichmentPlot <- function(signature, regulon, col="cornflowerblue", bins=length(signature)/20, offset=.1, sep=c("box", "line", "none"), xlab="", ylab="", ylim=NULL, ...) {
    sep <- match.arg(sep)
    if (is.numeric(signature) & !is.null(names(signature))) signature <- names(signature)[order(signature)]
    if (is.null(ylim)) ylim <- c(.5, length(regulon)+.5)
    plot(0, 0, type="n", xlab=xlab, ylab=ylab, xlim=c(0, length(signature)+1), axes=FALSE, ylim=ylim, yaxs="i", xaxs="i", ...)
    regulon <- rev(regulon)
    if (all(sapply(regulon, function(x) {
        if (is.numeric(x)) return(prod(range(x))<0)
        return(FALSE)
    }))) {
        if (length(col)==1) col <- rep(col, 2)
        col <- sapply(col, col2hsv)
        for (i in 1:length(regulon)) {
            reg <- list(names(regulon[[i]])[regulon[[i]]<0], names(regulon[[i]])[regulon[[i]]>=0])
            for (ii in 1:2) {
                densi <- rep(0, length(signature))
                x <- which(signature %in% reg[[ii]])
                if (length(x)>0) {
                    densi[x] <- 1
                    denStep <- round(length(densi)/bins)
                    x1 <- x[x<denStep]
                    x2 <- x[x>=denStep & x <= (length(signature)-denStep)]
                    x3 <- x[x>(length(signature)-denStep)]
                    densiRes <- sapply(x2, function(i, densi, denStep) sum(densi[(i-denStep):(i+denStep)]), densi=densi, denStep=denStep)
                    densiRes <- densiRes/max(densiRes)
                    temp <- hsv(col[1, ii], densiRes, 1-(1-col[3, ii])*densiRes)
                    if (ii==1) for (iii in order(densiRes)) lines(c(x[iii], x[iii]), c(i-.5+offset, i), col=temp[iii])
                    if (ii==2) for (iii in order(densiRes)) lines(c(x[iii], x[iii]), c(i, i+.5-offset), col=temp[iii])
                }
            }
            switch(sep, 
                   box={lines(c(0, length(signature)+1, length(signature)+1, 0, 0), c(i-.5+offset, i-.5+offset, i+.5-offset, i+.5-offset, i-.5+offset))},
                   line={
                       lines(c(0, length(signature)+1), c(i+.5, i+.5))
                       if (i==1) lines(c(0, length(signature)+1), c(.5, .5))
                   })
        }
    }
    else {
        col <- col2hsv(col)
        for (i in 1:length(regulon)) {
            densi <- rep(0, length(signature))
            x <- which(signature %in% regulon[[i]])
            if (length(x)>0) {
                densi[x] <- 1
                denStep <- round(length(densi)/bins)
                x1 <- x[x<denStep]
                x2 <- x[x>=denStep & x <= (length(signature)-denStep)]
                x3 <- x[x>(length(signature)-denStep)]
                densiRes <- sapply(x2, function(i, densi, denStep) sum(densi[(i-denStep):(i+denStep)]), densi=densi, denStep=denStep)
                densiRes <- densiRes/max(densiRes)
                temp <- hsv(col[1], densiRes, 1-(1-col[3])*densiRes)
                for (ii in order(densiRes)) lines(c(x[ii], x[ii]), c(i-.5+offset, i+.5-offset), col=temp[ii])
            }
            switch(sep, 
                   box={lines(c(0, length(signature)+1, length(signature)+1, 0, 0), c(i-.5+offset, i-.5+offset, i+.5-offset, i+.5-offset, i-.5+offset))},
                   line={
                       lines(c(0, length(signature)+1), c(i+.5, i+.5))
                       if (i==1) lines(c(0, length(signature)+1), c(.5, .5))
                   })
        }
    }
}

col2hsv <- function(color) {
    tmp <- col2rgb(color)
    rgb2hsv(tmp[1], tmp[2], tmp[3])
}

