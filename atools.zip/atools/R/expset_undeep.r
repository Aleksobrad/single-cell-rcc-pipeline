#Convert a list of varios levels to a uni-level list
expset.undeep <- function(expset) {
  expset.undeep.i(expset)
  lista <- get("lista", envir=as.environment(".GlobalEnv"))
  rm(list="lista",envir=as.environment(".GlobalEnv"))
  names(lista) <- list.names(expset)
  if (length(lista)==1) return(lista[[1]])
  else return(lista)
}
  
expset.undeep.i <- function(expset) {
  if (names(expset)[1] %in% c("expset","go.fold","expset.cluster","cor")) {
    if (!exists("lista", where=as.environment(".GlobalEnv"))) assign("lista",list(),envir=as.environment(".GlobalEnv"))
    lista <- get("lista", envir=as.environment(".GlobalEnv"))
    lista <- c(lista,list(expset))
    assign("lista",lista,envir=as.environment(".GlobalEnv"))
  }
  else lapply(expset, expset.undeep.i)
}
