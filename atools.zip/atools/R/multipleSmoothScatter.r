#' multipleSmoothScatter
#' 
#' This function plot smoothed scatter plots for several data groups
#' 
#' @param x Numeric vector of x positions
#' @param y Numeric vector of y positions
#' @param categories Factor defining the groups
#' @param col Vector of color hues, which should match the number of levels in the categories
#' @param dotcol Optional vector of colors for the dots
#' @param global Logical, whether the probability density should be globaly normalized
#' @param margin Number indicating the margin in percentage units
#' @param axes Logical, whether axis should be included
#' @param grid Integer indicating the density resolution, 0 to omit density plot
#' @param contour Integer indicating the number of contour lines to add
#' @param contourlabels LOgical, whether labels should be included in the contour plots
#' @param ... Additional parameters to pass to the \code{points} graphics generic function
#' @return A mapping function to transform coordinates into the plot space, which is generated in the default output device
#' @export
#' @examples
#' a <- cbind(rnorm(30), rnorm(30, sd=))
#' b <- cbind(rnorm(40, mean=8, sd=2), rnorm(40, mean=10, sd=2))
#' x <- c(a[, 1], b[, 1])
#' y <- c(a[, 2], b[, 2])
#' categ <- factor(rep(1:2, times=c(30, 40)))
#' multipleSmoothScatter(x, y, categ, pch=20)

multipleSmoothScatter <- function(x, y, categories, col, dotcol, global=FALSE, margin=5, axes=FALSE, grid=100, contour=0, contourlabels=TRUE, ...) {
    if (length(x) != length(y)) stop("x and y length should match", call.=FALSE)
    if (missing(categories)) categories <- rep(1, length(x))
    if (!(is(categories, "factor"))) categories <- factor(categories) 
    if (missing(col)) col <- seq(0, .7, length=length(levels(categories)))
    xlim <- range(x)
    ylim <- range(y)
    if (grid>0) {
        xlim <- xlim+diff(xlim)*c(-1, 1)*margin/grid
        ylim <- ylim+diff(ylim)*c(-1, 1)*margin/grid
        den2d <- tapply(1:length(x), categories, function(i, x, y, grid) {
            kde(cbind(x, y)[i, ], gridsize=grid, xmin=c(xlim[1], ylim[1]), xmax=c(xlim[2], ylim[2]))$estimate
        }, x=x, y=y, grid=grid)
    }
    else {
        xlim <- xlim+diff(xlim)*c(-1, 1)*margin/100
        ylim <- ylim+diff(ylim)*c(-1, 1)*margin/100
        den2d <- tapply(1:length(x), categories, function(i, x, y, grid) {
            kde(cbind(x, y)[i, ], gridsize=grid, xmin=c(xlim[1], ylim[1]), xmax=c(xlim[2], ylim[2]))$estimate
        }, x=x, y=y, grid=100)
    }
    if (global) den2d <- lapply(den2d, function(x, mm) x/mm, mm=max(sapply(den2d, max)))
    else den2d <- lapply(den2d, function(x) x/max(x))
    if (grid>0) image(den2d[[1]], col=hsv(col[1], sort(1-as.vector(den2d[[1]]^.5)), 1, sort(.5-as.vector(den2d[[1]]^.5/2))), axes=FALSE)
    else plot(0, 0, type="n", xlim=c(0, 1), ylim=c(0, 1), axes=FALSE, xlab="", ylab="", xaxs="i", yaxs="i")
    if (contour>0) {
        contour(den2d[[1]], nlevels=contour, add=TRUE, col=hsv(col[1], .8, .7, .5), drawlabels=contourlabels)
    }
    if (length(den2d)>1) tmp <- lapply(2:length(den2d), function(i, den2d, col, alpha, contour, contourlabels, grid) {
        if (grid>0) image(den2d[[i]], col=hsv(col[i], sort(1-as.vector(den2d[[i]]^.5)), 1, sort(.5-as.vector(den2d[[i]]^.5/2))), add=TRUE)
        if (contour>0) {
            contour(den2d[[i]], nlevels=contour, add=TRUE, col=hsv(col[i], .8, .7, .5), drawlabels=contourlabels)
        }
    }, den2d=den2d, col=col, alpha=alpha, contour=contour, contourlabels=contourlabels, grid=grid)
    a <- c(xlim[1], ylim[1])
    b <- 1/c(diff(xlim), diff(ylim))
    if (missing(dotcol)) dotcol <- hsv(col, .8, .7)[match(categories, levels(categories))]
    points((x-a[1])*b[1], (y-a[2])*b[2], col=dotcol, ...)
    if (axes) {
        posx <- pretty(xlim)
        posx <- posx[posx>=xlim[1] & posx<=xlim[2]]
        posy <- pretty(ylim)
        posy <- posy[posy>=ylim[1] & posy<=ylim[2]]
        axis(1, (posx-a[1])*b[1], posx)
        axis(2, (posy-a[2])*b[2], posy)
    }
    function(x, y) list(x=(x-a[1])*b[1], y=(y-a[2])*b[2])
}


