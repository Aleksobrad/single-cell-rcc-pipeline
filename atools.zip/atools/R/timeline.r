# Timeline plots

#' Import data from tab-delimited text files
#' 
#' This function imports data from tab delimited text files into a timeline object
#' 
#' @param filename Character string indicating the name of the input file
#' @return timeline object
#' @export
readTimeline <- function(filename) {
    tmp <- strsplit(gsub("\"", "", readLines(filename)[-1]), "\t")
    tl <- lapply(tmp, function(x) list(from=as.numeric(strsplit(x[2], ",")[[1]]), to=as.numeric(strsplit(x[3], ",")[[1]]), milestone=as.numeric(strsplit(x[4], ",")[[1]])))
    names(tl) <- sapply(tmp, function(x) x[1])
    class(tl) <- "timeline"
    return(tl)
}

#' Plot a timeline
#' 
#' This function generates a plot for a timeline
#' 
#' @param tl Timeline object
#' @param color Vector of colors for the timeline bars
#' @param border Vercor of colors for the timeline borders
#' @param labels Optional vector of labels, NA suppress labels. Default use timeline names
#' @param label.pos Position for the labels, default is outside
#' @param label.col Color for the labels, default is black
#' @param cex.label Number indicating the magnification for the labels
#' @param milestones Logical whether the milestones sould be plotted
#' @param ms.pch Symbol for the milestones
#' @param ms.col Color for the milestones
#' @param cex.ms Number indicating the magnification for the milestone symbols
#' @param xlab Character string indicating the label for the x-axis
#' @param sep Number indicating the fractional space between bars
#' @param axes Logical, whether x-axis should be added
#' @param ... Additional parameters to plot
#' @return Nothing, a plot is generated as side effect
#' @export
plot.timeline <- function(tl, color="grey", border="black", labels=NULL, label.pos="outside", label.col="black", cex.label=1, milestones=TRUE, ms.pch="|", ms.col="black", cex.ms=.5, xlab="", sep=.1, axes=TRUE, xlim=NULL, ...) {
    if (length(tl)>length(label.pos)) label.pos <- rep(label.pos[1], length(tl))
    if (length(tl)>length(color)) color <- rep(color[1], length(tl))
    if (length(tl)>length(border)) border <- rep(border[1], length(tl))
    if (length(tl)>length(label.col)) label.col <- rep(label.col[1], length(tl))
    if (length(tl)>length(ms.pch)) ms.pch <- rep(ms.pch[1], length(tl))
    if (length(tl)>length(ms.col)) ms.col <- rep(ms.col[1], length(tl))
    tt <- t(sapply(tl, function(x) c(min(x$from), max(x$to))))
    if (is.null(xlim)) xlim <- c(min(tt[, 1]), max(tt[, 2]))
    plot(0, 0, type="n", xlim=xlim, ylim=c(0, length(tl))+.5, axes=FALSE, xlab=xlab, ylab="", ...)
    if (axes) axis(1, seq(xlim[1], xlim[2], length=5))
    for (i in 1:length(tl)) {
        y <- length(tl)-i+1
        for (ii in 1:min(length(tl[[i]]$from), length(tl[[i]]$to))) rect(tl[[i]]$from[ii], y-.5+sep, tl[[i]]$to[ii], y+.5-sep, col=color[i], border=border[i])
    }
    for (i in 1:length(tl)) {
        switch(match.arg(label.pos[i], c("outside", "inside", "left", "right", "none")),
        outside={
            axis(2, length(tl)-i+1, names(tl)[i], cex.axis=cex.label, tick=FALSE, line=-.5, col=label.col[i], las=2)
        },
        inside={
            for (ii in 1:min(length(tl[[i]]$from), length(tl[[i]]$to))) text((tl[[i]]$from[ii]+tl[[i]]$to[ii])/2, length(tl)-i+1, names(tl)[i], col=label.col[i], cex=cex.label)
        },
        left={
            for (ii in 1:min(length(tl[[i]]$from), length(tl[[i]]$to))) text(tl[[i]]$from[ii]-diff(xlim)/80, length(tl)-i+1, names(tl)[i], col=label.col[i], cex=cex.label, adj=1)
        },
        right={
            for (ii in 1:min(length(tl[[i]]$from), length(tl[[i]]$to))) text(tl[[i]]$to[ii]+diff(xlim)/80, length(tl)-i+1, names(tl)[i], col=label.col[i], cex=cex.label, adj=0)
        },
        none={})
    }
    if (milestones) {
        for (i in 1:length(tl)) {
            points(tl[[i]]$milestone, rep(length(tl)-i+.5+sep, length(tl[[i]]$milestone)), pch=ms.pch[i], col=ms.col[i], cex=cex.ms)
        }
    }
}
