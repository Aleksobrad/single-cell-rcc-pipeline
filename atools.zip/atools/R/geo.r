#' Function for generating Gene Expression Omnibus PLATFORM SOFTtext files
#'
#' This function generates GEO PLATFORM SOFTtext files
#'
#' @param database Character string indicating the name of the database file
#' @param psf Character string indicating the name of the print setup file
#' @param filter List of components of the database for filtering the information including labels, for example: \code{filter=list(Model=c(\"breast\", \"colon\"), Time=c(18, 72))}
#' @param output Character string indicating the name of the output file
#' @param technology Character string indicating the platform_technology, either spotted DNA/cDNA, in situ oligonucleotide, spotted oligonucleotide, antibody, tissue, MS, MPSS
#' @param distribution Character string indicating the platform_distribution, either non-commercial, commercial, custom-commercial
#' @param organism Character string indicating the platform_organism
#' @param manufacturer Character string indicating the platform_manufacterer
#' @param protocol Character string indicating the platform_protocol
#' @param support Character string indicating the platform_material, i.e. glass
#' @param coating Character string indicating the coating material, i.e. aminosilane
#' @param contributor Vectro of character strings indicating the name of the contributors, as First, Initial, Last names
#' @return Nothing, a SOFTtext file is generated
#' @export

#PLATFORM generation from GENTRON's database files

geo.platform <- function(database, psf="psf", filter=list(), output="platform",
technology="[required][VALUE=spotted DNA/cDNA, in situ oligonucleotide,spotted oligonucleotide, antibody, tissue, MS, MPSS]",
distribution="[required][VALUE=non-commercial, commercial, custom-commercial]",
organism="[required]", manufacturer="[required]", protocol="[required]",
support="glass", coating="aminosilane", contributor=NULL) {
  db <- read.table(paste(database,".txt",sep=""),sep="\t",header=T,fill=T,quote="",comment.char="")
  psf <- read.table(paste(psf,".txt",sep=""), sep="\t", header=T, fill=T)
  filtro <- rep(T,nrow(db))
  if (length(filter)>0) for (i in 1:length(filter)) filtro <- filtro & db[,colnames(db)==names(filter)[i]] %in% filter[[i]]
  layout.pos <- which(colnames(db) == "Layout")
  platforms <- unique(as.vector(db[filtro,layout.pos]))
  out <- file(paste(output,".txt",sep=""), "w")
  for (p in platforms) {
    datos <- read.table(paste(p,".txt",sep=""), sep="\t", header=T, fill=T)
    cat("^PLATFORM=", p, "\n", sep="", file=out)
    cat("!Platform_title = ",p,"\n", sep="", file=out)
    cat("!Platform_technology = ",technology,"\n", sep="", file=out)
    cat("!Platform_distribution = ",distribution,"\n", sep="", file=out)
    cat("!Platform_organism = ", organism, "\n", sep="", file=out)
    cat("!Platform_manufacturer = ",manufacturer,"\n", sep="", file=out)
    cat("!Platform_manufacture_protocol = ",protocol,"\n", sep="", file=out)
    cat("!Platform_support = ", support, "\n", sep="", file=out)
    cat("!Platform_coating = ", coating, "\n", sep="", file=out)
    if (!is.null(contributor)) cat(paste(paste("!Platform_contributor = ", contributor, sep=""), collapse="\n"),"\n", sep="", file=out)
    cat("#ID =\n", file=out)
    cat("#GB_ACC = GenBank accession number of sequence used to design oligonucleotide probe\n", file=out)
    cat("#GENE_NAME = Descriptive gene name\n", file=out)
    cat("#SPOT_ID = Alternative spot identifier\n", file=out)
    cat("#TIP_ID = Print tip ID\n", file=out)
    cat("#M_ROW = Grid row\n", file=out)
    cat("#M_COLUMN = Grid column\n", file=out)
    cat("#S_ROW = Spot row within the print grid\n", file=out)
    cat("#S_COLUMN = Spot column within array\n", file=out)
    cat("!Platform_table_begin\nID\tGB_ACC\tGENE_NAME\tSPOT_ID\tTIP_ID\tM_ROW\tM_COLUMN\tS_ROW\tS_COLUMN\n", file=out)
    pins <- as.numeric(psf[psf$Layout==p,2:3])
    ptip <- datos$Grid/prod(pins)
    ptip <- (ptip-floor(ptip))*prod(pins)
    ptip[ptip==0] <- prod(pins)
    m.row <- floor(datos$Grid/(pins[2]+1))+1
    m.col <- datos$Grid/pins[2]
    m.col <- (m.col-floor(m.col))*pins[2]
    m.col[m.col==0] <- pins[2]
    datos <- as.matrix(datos)
    accesos <- which(colnames(datos)=="Access")
    nombres <- which(colnames(datos)=="Name")
    ids <- which(colnames(datos)=="ID")
    for (i in 1:nrow(datos)) {
      cat(i,datos[i,accesos],datos[i,nombres],datos[i,ids],ptip[i],m.row[i],m.col[i],datos$Row[i],datos$Col[i], sep="\t", file=out)
      cat("\n", file=out)
    }
    cat("!Platform_table_end\n\n", file=out)
  }
  close(out)
}

#' Sample SOFTtext file forma generation
#'
#' This function generates GEO Sample SOFTtext files
#'
#' @param expset Expression-set in matrix format
#' @param db Character string indicating the name of the annotation database
#' @param organism Character string indicating the organism
#' @param molecule Character string indicating the hybridization material
#' @param sample Character string indicating the sample data
#' @param platform Character string indicating the platform
#' @param output Character string indicating the name of the output file
#' @param supplementary Logical, whether supplementary files will be included
#' @return Nothing, a plain SOFTtest file is generated
#' @export

geo.sample.affy <- function(expset, db, organism="Homo", molecule="Total RNA", sample="Normalization and summarization by MAS5 implemented in affy package / bioconductor (www.bioconductor.org), and log2 transformation", platform="GPL8300", output="sample", supplementary=T) {
  db <- strsplit.matrix(readLines(db), "\t")
  d1 <- readExpset(expset)
  colnames(d1) <- gsub(".CEL", "", colnames(d1))
  out <- file(paste(output,".txt",sep=""),open="w")
  for (i in 1:ncol(d1)) {
    cat("^SAMPLE = ", colnames(d1)[i], "\n", sep="", file=out)
    cat("!Sample_title = ", colnames(d1)[i], "\n", sep="", file=out)
    if (supplementary) cat("!Sample_supplementary_file = ", colnames(d1)[i], ".CEL\n", sep="", file=out)
    cat("!Sample_source_name = ", db[db[, 1]==colnames(d1)[i], 2], "\n", sep="", file=out)
    cat("!Sample_organism = ", names(which.specie(organism)), "\n", sep="", file=out)
    temp <- strsplit(db[db[, 1]==colnames(d1)[i], 3], ";")[[1]]
    temp <- lapply(temp, function(x, out) cat("!Sample_characteristics = ", x, "\n", sep="", file=out), out=out)
    cat("!Sample_molecule = ", molecule, "\n", sep="", file=out)
    cat("!Sample_extract_protocol = ", db[db[, 1]==colnames(d1)[i], 4], "\n", sep="", file=out)
    cat("!Sample_label = biotin\n", file=out)
    cat("!Sample_label_protocol = ", db[db[, 1]==colnames(d1)[i], 5], "\n", sep="", file=out)
    cat("!Sample_hyb_protocol = ", db[db[, 1]==colnames(d1)[i], 6], "\n", sep="", file=out)
    cat("!Sample_scan_protocol = The arrays were processed on a Gene Chip Fluidics Station 450 and scanned on a Affymetrix GeneChip Scanner (Santa Clara, CA).\n", file=out)
    cat("!Sample_data_processing = ", sample, "\n", sep="", file=out)
    cat("!Sample_description = ", db[db[, 1]==colnames(d1)[i], 7], "\n", sep="", file=out)
    cat("!Sample_platform_id = ", platform, "\n", sep="", file=out)
    cat("#ID_REF = Probe set identifiers, each of which is unique to a specific probe set.\n#VALUE = This is the final calculated measurement for each probe set identifer after normalization\n", sep="", file=out)
    cat("!Sample_table_begin\n", file=out)
    cat("ID_REF\tVALUE\n", file=out)
    cat(paste(paste(rownames(d1), d1[, i], sep="\t"), collapse="\n"), "\n", sep="", file=out)
    cat("!Sample_table_end\n\n", sep="", file=out)
  }
  close(out)
}

