# Significance tests

#' Test for significance of correlation coefficient
#' 
#' This function test whether the correlation coefficient differs from zero
#' 
#' @param r Correlation between x and y
#' @param n sample size
#' @param alternative character string indicating the alternative hypothesis
#' @return z-score and p-value
#' @export
cortest <- function(r, n, alternative="two.sided") {
  z <- log((1+r)/(1-r))/2*sqrt(n-3)
  switch(match.arg(alternative, c("two.sided", "less", "greater")),
         two.sided={p <- pnorm(abs(z), lower.tail=F)*2},
         less={p <- pnorm(z, lower.tail=T)},
         greater={p <- pnorm(z, lower.tail=F)})
  return(list(z=z, p.value=p))
}

#' Difference between correlation coefficients from independent samples
#' 
#' This function estimates the statistical difference between correlation coefficients computed on independent samples
#' 
#' @param r1 The correlation coefficient between x and y
#' @param r2 The correlation coefficient between z and j
#' @param n1 Sample size for x and y
#' @param n2 Sample size for z and j
#' @param alternative Character string indicating the alternative hypothesis
#' @return List containing the z-scores and p-values
#' @export
cordif <- function (r1, r2, n1, n2, alternative="two.sided") {
  z1 <- 0.5 * ((log(1 + r1)) - (log(1 - r1)))
  z2 <- 0.5 * ((log(1 + r2)) - (log(1 - r2)))
  zest <- (z1 - z2)/sqrt(1/(n1 - 3) + 1/(n2 - 3))
  switch(match.arg(alternative, c("two.sided", "less", "greater")),
         two.sided={p <- pnorm(abs(zest), lower.tail=F)*2},
         less={p <- pnorm(zest, lower.tail=T)},
         greater={p <- pnorm(zest, lower.tail=F)})
  return(list(z=zest, p.value=p))
}

#' Difference between correlation coefficients from dependent samples
#' 
#' This function estimates the statistical difference between correlation coefficients computed on dependent samples
#' 
#' @param r.x1y The correlation coefficient between x1 and y
#' @param r.x2y The correlation coefficient between x2 and y
#' @param r.x1x2 The correlation coefficient between x1 and x2
#' @param n Sample size
#' @param alternative Character string indicating the alternative hypothesis
#' @return List containing the t-statistics, degrees of freedom and p-values
#' @export
cordifdep <- function (r.x1y, r.x2y, r.x1x2, n, alternative="two.sided") {
  rbar <- (r.x1y + r.x2y)/2
  barRbar <- 1 - r.x1y^2 - r.x2y^2 - r.x1x2^2 + 2 * r.x1y * 
    r.x2y * r.x1x2
  tvalue.num <- ((r.x1y - r.x2y) * sqrt((n - 1) * (1 + r.x1x2)))
  tvalue.den <- sqrt(((2 * ((n - 1)/(n - 3))) * barRbar + ((rbar^2)) * 
                        (1 - r.x1x2)^3))
  t.value <- tvalue.num/tvalue.den
  DF <- n - 3
  switch(match.arg(alternative, c("two.sided", "less", "greater")),
         two.sided={p <- pt(abs(t.value), DF, lower.tail=F)*2},
         less={p <- pt(t.value, DF, lower.tail=T)},
         greater={p <- pt(t.value, DF, lower.tail=F)})
  return(list(t=t.value, df=DF, p.value=p))  
}
