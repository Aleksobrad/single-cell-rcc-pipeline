#Color definitions

pseudocolor <- function(x, gamma1=2, gamma2=2, offset=.25) c(hsv(.67,1,seq(0,1,length=offset*x)^gamma1),hsv(seq(1,0,length=(1-offset)*x)^gamma2*.67,1,1))

#' colorScale
#' 
#' This function generates a color scale
#' 
#' @param x Vector or matrix of numeric values
#' @param color Vector of character strings indicating the colors for the scale. Up to three colors can be defined. While is used for the missing color
#' @param gama Number indicating the gama transformation
#' @param alpha Number between 0 and 1 indicating the transparency of the color (1 for absolute color)
#' @param scmax Number indicating the maximum value for the scale
#' @param nacol Character string indicating the color for missing values
#' @return Vector of colors
#' @export
colorScale <- function(x, color=c("royalblue","firebrick2"), gama=1, alpha=1, scmax=0, nacol="grey80") {
    if (length(color)==1) color <- c(color, "white", color)
    if (length(color)==2) color <- c(color[1], "white", color[2])
    if (scmax==0) scmax <- max(abs(x), na.rm=T)
    pos <- which(abs(x) > scmax)
    if (length(pos)>0) x[pos] <- scmax*sign(x[pos])
    x <- abs(x/scmax)^gama*sign(x)
    color <- t(col2rgb(color))
    col <- sapply(x, function(x, color) {
        colSums(color*c(abs(x)*(x<0), 1-abs(x), x*(x>0)))
    }, color=color/255)
    apply(col, 2, function(x, alpha) rgb(x[1], x[2], x[3], alpha=alpha), alpha=alpha)
}
