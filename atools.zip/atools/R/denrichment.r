#' Denrichment plot
#'
#' This function generates a density plot with enrichment lines
#' 
#' @param x Numeric vector of values to plot
#' @param xlim Vector containing the min and max values to plot
#' @param color Number between 0 and 1 indicating HUE of the color to use for the bars, or character string indicating the color name
#' @param adj Number indicating the bandwidth factor
#' @param add Logical, whether the plot should be added to an existing plot
#' @return Nothing, a plot is generated in the default output device
#' @export

denrichment <- function(x, xlim=range(x), color="green", adj=1.5, add=FALSE) {
    if (is.character(color)) color <- rgb2hsv(col2rgb(color))[1]
    den <- density(x, from=xlim[1], to=xlim[2], adj=adj)
    den <- list(x=den$x, y=den$y/max(den$y))
    if (!(add)) plot(0, 0, type="n", ylim=c(0, 1), xlim=xlim, axes=FALSE, xlab="", ylab="")
    tmp <- lapply(1:length(x), function(i, x, y, col) {
        lines(c(x[i], x[i]), c(0, y[i]), col=col[i])
    }, x=x, y=approx(den$x, den$y, x)$y, col=hsv(color, approx(den$x, (den$y+.3)/1.3, x)$y, approx(den$x, (1-den$y+.5)/1.5, x)$y))
    lines(den)
}
